package supermarket.sort;

import java.util.List;
import java.util.Vector;

public interface SortManageIDAO {
	public boolean addSort(SortManage sort);
	public boolean updateSort(SortManage sort);
	public boolean deleteSort(String Sort);
	public Vector<SortManage> findAllSort();
	public Vector<SortManage> findByName(String Sort);
}
