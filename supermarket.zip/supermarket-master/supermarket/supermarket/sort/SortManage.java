package supermarket.sort;

public class SortManage {
	private String Sort;
	private String State;
	@Override
	public String toString() {
		return "商品分类[" + Sort + "]      分类状态[" + State + "]";
	}
	public SortManage() {
		super();
	}
	public SortManage(String sort, String state) {
		super();
		this.Sort = sort;
		this.State = state;
	}

	public String getSort() {
		return Sort;
	}

	public void setSort(String sort) {
		Sort = sort;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}
}
