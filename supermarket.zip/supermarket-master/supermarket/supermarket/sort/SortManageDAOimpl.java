package supermarket.sort;

import supermarket.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

public class SortManageDAOimpl implements SortManageIDAO{

	@Override
	public boolean addSort(SortManage sort) {
		Connection conn = null;
		PreparedStatement pst = null;
		int num=0;
		try {
			conn = ConnectionFactory.getConnection();
			String sql = "insert into sorttab values (?,?)";
			pst = conn.prepareStatement(sql);
			pst.setString(1, sort.getSort());
			pst.setString(2, sort.getState());
			num = pst.executeUpdate();
			if(num==1) {
				return true;
			}else return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			CloseResource.close(pst, conn);
		}
	}
	
	@Override
	public boolean updateSort(SortManage sort) {
		Connection conn = null;
		PreparedStatement pst = null;
		int num=0;
		try {
			conn = ConnectionFactory.getConnection();
			String sql = "update sorttab set State=? where sort=?";
			pst = conn.prepareStatement(sql);
			pst.setString(2, sort.getSort());
			pst.setString(1, sort.getState());
			num = pst.executeUpdate();
			if(num==1) {
				return true;
			}else return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			CloseResource.close(pst, conn);
		}
	}

	@Override
	public boolean deleteSort(String Sort) {
		Connection conn = null;
		PreparedStatement pst = null;
		int num=0;
		try {
			conn = ConnectionFactory.getConnection();
			String sql = "delete from sorttab where sort=?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, Sort);
			num = pst.executeUpdate();
			if(num==1) {
				return true;
			}else return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		} finally {
			CloseResource.close(pst, conn);
		}
	}

	@Override
	public Vector<SortManage> findAllSort() {
		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		SortManage sort = null;
		Vector<SortManage> vector = new Vector<SortManage>();
		try {
			conn = ConnectionFactory.getConnection();
			String sql = "select * from sorttab";
			st = conn.createStatement();
			rs = st.executeQuery(sql);
			while(rs.next()) {
				sort = new SortManage();
				sort.setSort(rs.getString(1));
				sort.setState(rs.getString(2));
				vector.add(sort);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseResource.close(rs, st, conn);
		}
		return vector;
	}

	@Override
	public Vector<SortManage> findByName(String Sort) {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		SortManage sort = null;
		Vector<SortManage> vector = new Vector<SortManage>();
		try {
			conn = ConnectionFactory.getConnection();
			String sql = "select * from sorttab where sort = ?";
			pst = conn.prepareStatement(sql);
			pst.setString(1, Sort);
			rs = pst.executeQuery();
			while(rs.next()) {
				sort = new SortManage();
				sort.setSort(rs.getString(1));
				sort.setState(rs.getString(2));
				vector.add(sort);
			} 
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			CloseResource.close(rs, pst, conn);
		}
		return vector;
	}
	
}
