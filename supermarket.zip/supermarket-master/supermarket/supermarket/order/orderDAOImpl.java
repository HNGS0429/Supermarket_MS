package supermarket.order;

import supermarket.CloseResource;
import supermarket.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class orderDAOImpl implements orderDAO{
    @Override
    public boolean AddOrder(order order) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "insert into orders values(?,?,?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,order.getCid());
            pst.setString(2,order.getName());
            pst.setInt(3,order.getNum());
            pst.setString(4,order.getId());
            pst.setString(5,order.getDate());
            pst.setString(6,order.getPerson());
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }

    @Override
    public Vector<order> selectByid(String id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        order order = null;
        Vector<order> vector = new Vector<order>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from orders where id = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1,id);
            rs = pst.executeQuery();
            while(rs.next())
            {
                order = new order();
                order.setCid(rs.getInt(1));
                order.setName(rs.getString(2));
                order.setNum(rs.getInt(3));
                order.setId(rs.getString(4));
                order.setDate(rs.getString(5));
                order.setPerson(rs.getString(6));
                vector.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }

    @Override
    public Vector<order> selectByDate(String date) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        order order = null;
        Vector<order> vector = new Vector<order>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from orders where dates = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1,date);
            rs = pst.executeQuery();
            while(rs.next())
            {
                order = new order();
                order.setCid(rs.getInt(1));
                order.setName(rs.getString(2));
                order.setNum(rs.getInt(3));
                order.setId(rs.getString(4));
                order.setDate(rs.getString(5));
                order.setPerson(rs.getString(6));
                vector.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }

    @Override
    public Vector<order> selectCommdifyById(int cid) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        order order;
        Vector<order> vector = new Vector<order>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from orders where cid = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,cid);
            rs = pst.executeQuery();
            while(rs.next())
            {
                order = new order();
                order.setCid(rs.getInt(1));
                order.setName(rs.getString(2));
                order.setNum(rs.getInt(3));
                order.setId(rs.getString(4));
                order.setDate(rs.getString(5));
                order.setPerson(rs.getString(6));
                vector.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }
}
