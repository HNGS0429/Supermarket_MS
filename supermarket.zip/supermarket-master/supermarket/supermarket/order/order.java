package supermarket.order;

public class order {
    private int cid;
    private String name;
    private int num;
    private String id;
    private String date;
    private String person;

    public order(int cid, String name, int num, String id, String date, String person) {
        super();
        this.cid = cid;
        this.name = name;
        this.num = num;
        this.id = id;
        this.date = date;
        this.person = person;
    }

    public order() {
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPerson() {
        return person;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    @Override
    public String toString() {
        return  "商品名称[" + name + "]     购买数量[" + num + "]     订单编号[" + id + "]     创建时间[" + date + "]     操作员[" + person + "]";
    }
}
