package supermarket.order;

import java.util.Vector;

public interface orderDAO {
    public boolean AddOrder(order order);
    public Vector<order> selectByid(String id);
    public Vector<order> selectByDate(String date);
    public Vector<order> selectCommdifyById(int cid);
}
