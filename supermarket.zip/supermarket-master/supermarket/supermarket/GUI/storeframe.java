package supermarket.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class storeframe {
    JFrame storeframe = new JFrame("库管员");
    JButton commodity = new JButton("商品管理");
    JButton classify = new JButton("分类管理");
    JButton purchase = new JButton("进货管理");
    public void store()
    {
        storeframe.setBounds(744,374,429,359);
        storeframe.setResizable(false);
        storeframe.setLayout(null);
        storeframe.setVisible(true);
        commodity.setFont(new Font("微软雅黑",Font.PLAIN,20));
        commodity.setBounds(71,60,270,50);
        commodity.addActionListener(new commodifyListener());
        classify.setFont(new Font("微软雅黑",Font.PLAIN,20));
        classify.setBounds(71,130,270,50);
        classify.addActionListener(new classifyLitener());
        purchase.setFont(new Font("微软雅黑",Font.PLAIN,20));
        purchase.setBounds(71,200,270,50);
        purchase.addActionListener(new purchaseLitener());

        storeframe.add(commodity);
        storeframe.add(classify);
        storeframe.add(purchase);
        storeframe.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                storeframe.dispose();
                new mainframe().Main();
            }
        });
    }
    private class commodifyListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyframe().Commodify();
        }
    }
    private class classifyLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new sortframe().Sort();
        }
    }

    private class purchaseLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new purchaseaddframe().Add();
        }
    }


}





