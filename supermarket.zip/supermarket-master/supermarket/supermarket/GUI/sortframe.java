package supermarket.GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class sortframe {
    JFrame sortframe = new JFrame("商品管理");
    JButton addsortframe = new JButton("添加分类信息");
    JButton deletesortframe = new JButton("删除分类信息");
    JButton updatesortframe = new JButton("修改分类信息");
    JButton selectsortframe = new JButton("查询分类信息");
    public void Sort()
    {
        sortframe.setResizable(false);
        sortframe.setLayout(null);
        addsortframe.setBounds(71,40,270,40);
        addsortframe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new sortaddframe().Add();
            }
        });
        deletesortframe.setBounds(71,100,270,40);
        deletesortframe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new sortdeleteframe().Delete();
            }
        });
        updatesortframe.setBounds(71,160,270,40);
        updatesortframe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new sortupdateframe().Update();
            }
        });
        selectsortframe.setBounds(71,220,270,40);
        selectsortframe.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new sortselectframe().Select();
            }
        });
        sortframe.add(addsortframe);
        sortframe.add(deletesortframe);
        sortframe.add(updatesortframe);
        sortframe.add(selectsortframe);
        sortframe.setVisible(true);
        sortframe.setBounds(744,374,429,359);
        sortframe.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }


}
