package supermarket.GUI;

import supermarket.commodify.commodifyDAOImpl;
import supermarket.order.order;
import supermarket.order.orderDAOImpl;
import supermarket.user.UserDAOimpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class accountframe {
    JFrame account = new JFrame("商品结算");
    JButton submit = new JButton("提交订单");
    JLabel id = new JLabel("商品编号");
    JLabel name = new JLabel("商品名称");
    JLabel num = new JLabel("购买数量");
    JLabel order_num = new JLabel("订单单号");
    JLabel create_time = new JLabel("创建时间");
    JLabel user_id = new JLabel("操作人员");
    JTextField id_tx = new JTextField();
    JTextField name_tx = new JTextField();
    JTextField num_tx = new JTextField();
    JTextField order_num_tx = new JTextField();
    JComboBox year = new JComboBox();
    JComboBox month = new JComboBox();
    JComboBox day = new JComboBox();
    JTextField user_id_tx = new JTextField();
    public void Account()
    {
        account.setResizable(false);
        account.setLayout(null);
        id.setFont(new Font("微软雅黑",Font.PLAIN,15));
        id.setBounds(41,30,60,30);
        id_tx.setBounds(111,30,240,30);
        name.setFont(new Font("微软雅黑",Font.PLAIN,15));
        name.setBounds(41,70,60,30);
        name_tx.setBounds(111,70,240,30);
        num.setFont(new Font("微软雅黑",Font.PLAIN,15));
        num.setBounds(41,110,60,30);
        num_tx.setBounds(111,110,240,30);
        order_num.setFont(new Font("微软雅黑",Font.PLAIN,15));
        order_num.setBounds(41,150,60,30);
        order_num_tx.setBounds(111,150,240,30);
        create_time.setFont(new Font("微软雅黑",Font.PLAIN,15));
        create_time.setBounds(41,190,60,30);
        year.setBounds(111,190,100,30);
        for(int i=1990;i<2050;i++)
        {
            year.addItem(i+"年");
        }
        month.setBounds(211,190,70,30);
        for(int i=1;i<13;i++)
        {
            month.addItem(i+"月");
        }
        year.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String y = (String) year.getSelectedItem();
                y = y.substring(0,4);
                int year = Integer.parseInt(y);
                if((year % 4==0 && year%100!=0) || year%400==0)
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "2月":
                                    for(int i=1;i<30;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "1月","3月","5月","7月","8月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "4月","6月","9月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                            }
                        }
                    });
                }
                else
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "2月":
                                    for(int i=1;i<29;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "1月","3月","5月","7月","8月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "4月","6月","9月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                            }
                        }
                    });
                }
            }
        });

        day.setBounds(281,190,70,30);
//
        user_id.setFont(new Font("微软雅黑",Font.PLAIN,15));
        user_id.setBounds(41,230,60,30);
        user_id_tx.setBounds(111,230,240,30);
        submit.setBounds(250,270,100,30);
        submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JDialog comp = new JDialog();
                JButton sure = new JButton("确定");
                JLabel tip = new JLabel("请输入正确");
                JLabel tip2 = new JLabel("的商品编号");
                sure.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        comp.dispose();
                    }
                });
                sure.setBounds(60, 80, 60, 20);
                tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
                tip.setBounds(50, 10, 100, 30);
                tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
                tip2.setBounds(50, 40, 100, 30);
                comp.setLayout(null);
                comp.setResizable(false);
                comp.setBounds(859, 474, 200, 160);
                comp.add(tip);
                comp.add(tip2);
                comp.add(sure);
                String id = id_tx.getText();
                String name = name_tx.getText();
                String num = num_tx.getText();
                String ordernum = order_num_tx.getText();
                String time = (String) year.getSelectedItem() + month.getSelectedItem() + day.getSelectedItem();
                String person = user_id_tx.getText();
                commodifyDAOImpl cd = new commodifyDAOImpl();
                UserDAOimpl ud = new UserDAOimpl();
                orderDAOImpl od = new orderDAOImpl();
                order order = new order();
                if(id.equals("") || name.equals("") || num.equals("") || ordernum.equals("") || person.equals(""))
                {
                    tip.setText("请输入正确");
                    tip2.setText("的订单信息");
                    sure.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            comp.dispose();
                        }
                    });
                }
                else
                {
                    int id_s = Integer.parseInt(id);
                    int num_s = Integer.parseInt(num);
                    if(cd.selectByNameandID(id_s,name).isEmpty())
                    {
                        tip.setText("请输入正确");
                        tip2.setText("的商品信息");
                        sure.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                comp.dispose();
                            }
                        });
                    }
                    else
                    {
                        if(cd.selectNum(id_s)==0)
                        {
                            tip.setText("该商品暂时");
                            tip2.setText("无货");
                            sure.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    comp.dispose();
                                }
                            });
                        }
                        else if(cd.selectNum(id_s)-num_s<0)
                        {
                            tip.setText("库存少于");
                            tip2.setText("购买数量");
                            sure.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    comp.dispose();
                                }
                            });
                        }
                        else
                        {
                            if(ud.logon(person) == null)
                            {
                                tip.setText("请输入正确");
                                tip2.setText("的操作人员");
                                sure.addActionListener(new ActionListener() {
                                    @Override
                                    public void actionPerformed(ActionEvent e) {
                                        comp.dispose();
                                    }
                                });
                            }
                            else
                            {
                                order.setCid(id_s);
                                order.setName(name);
                                order.setNum(num_s);
                                order.setId(ordernum);
                                order.setDate(time);
                                order.setPerson(person);
                                if(od.AddOrder(order))
                                {
                                    tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                                    tip.setBounds(50,20,100,40);
                                    tip2.setVisible(false);
                                    tip.setText("添加完成");
                                    sure.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            int new_num = cd.selectNum(id_s) - num_s;
                                            cd.updateNum(new_num,id_s);
                                            comp.dispose();
                                        }
                                    });
                                }
                                else
                                {
                                    tip.setText("订单编号");
                                    tip2.setText("不能重复");
                                    sure.addActionListener(new ActionListener() {
                                        @Override
                                        public void actionPerformed(ActionEvent e) {
                                            comp.dispose();
                                        }
                                    });
                                }
                            }
                        }
                    }
                }
                comp.setVisible(true);

            }
        });

        account.add(id);
        account.add(id_tx);
        account.add(name);
        account.add(name_tx);
        account.add(num);
        account.add(num_tx);
        account.add(order_num);
        account.add(order_num_tx);
        account.add(create_time);
        account.add(year);
        account.add(month);
        account.add(day);
        account.add(user_id);
        account.add(user_id_tx);
        account.add(submit);
        account.setVisible(true);
        account.setBounds(744,374,429,359);
        account.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }


}
