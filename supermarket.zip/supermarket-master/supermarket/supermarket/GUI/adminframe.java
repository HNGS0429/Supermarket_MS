package supermarket.GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class adminframe {
    JFrame adminframe = new JFrame("管理员");
    JButton commodity = new JButton("商品管理");
    JButton classify = new JButton("分类管理");
    JButton account = new JButton("商品结算");
    JButton order = new JButton("订单查询");
    JButton purchase = new JButton("进货管理");
    public void admin()
    {
        adminframe.setBounds(744,374,429,359);
        adminframe.setResizable(false);
        adminframe.setLayout(null);
        adminframe.setVisible(true);
        commodity.setBounds(71,30,270,30);
        commodity.addActionListener(new commodifyListener());
        classify.setBounds(71,80,270,30);
        classify.addActionListener(new classifyLitener());
        account.setBounds(71,130,270,30);
        account.addActionListener(new accountLitener());
        order.setBounds(71,180,270,30);
        order.addActionListener(new orderLitener());
        purchase.setBounds(71,230,270,30);
        purchase.addActionListener(new purchaseLitener());

        adminframe.add(commodity);
        adminframe.add(classify);
        adminframe.add(account);
        adminframe.add(order);
        adminframe.add(purchase);
        adminframe.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                adminframe.dispose();
                new mainframe().Main();
            }
        });
    }
    private class commodifyListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyframe().Commodify();
        }
    }
    private class classifyLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new sortframe().Sort();
        }
    }
    private class accountLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new accountframe().Account();
        }
    }
    private class orderLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new orderframe().Order();
        }
    }
    private class purchaseLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new purchaseaddframe().Add();
        }
    }


}





