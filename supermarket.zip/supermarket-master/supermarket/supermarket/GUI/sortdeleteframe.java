package supermarket.GUI;

import supermarket.commodify.*;
import supermarket.sort.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class sortdeleteframe {
    JFrame sortdelete = new JFrame("删除分类信息");
    JLabel sort = new JLabel("分类名称");

    JTextField sort_tx = new JTextField();

    JButton sure = new JButton("删除");
    JButton cancel = new JButton("取消");
    public void Delete() {
        sort.setFont(new Font("微软雅黑",Font.PLAIN,15));
        sort.setBounds(41,70,60,30);
        sort_tx.setBounds(111,70,240,30);
        sure.setBounds(111, 130, 75, 30);
        sure.addActionListener(new sureButton(sort_tx));
        cancel.setBounds(274, 130, 75, 30);
        cancel.addActionListener(new cancelButton());

        sortdelete.setBounds(744, 374, 429, 359);
        sortdelete.setResizable(false);
        sortdelete.setLayout(null);
        sortdelete.setVisible(true);
        sortdelete.add(sort);
        sortdelete.add(sort_tx);
        sortdelete.add(sure);
        sortdelete.add(cancel);
        sortdelete.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new sortframe().Sort();
            }
        });
    }
    private class sureButton implements ActionListener
    {
        JTextField sort_tx = new JTextField();

        public sureButton(JTextField sort_tx) {
            this.sort_tx = sort_tx;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            JLabel tip2 = new JLabel();
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String sort = sort_tx.getText();
            if(sort.equals(""))
            {
                tip.setText("请输入正确");
                tip2.setText("的分类信息");
            }
            else
            {
                SortManageDAOimpl sd = new SortManageDAOimpl();
                commodifyDAOImpl cd = new commodifyDAOImpl();
                if(cd.selectBySort(sort).isEmpty())
                {
                    if(sd.deleteSort(sort))
                    {
                        tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                        tip.setBounds(50,20,100,40);
                        tip2.setVisible(false);
                        tip.setText("删除完成");
                    }
                    else
                    {
                        tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                        tip.setBounds(50,20,100,40);
                        tip2.setVisible(false);
                        tip.setText("删除失败");
                    }
                }
                else
                {
                    tip.setText("该分类下");
                    tip2.setText("有商品");
                }
            }
            comp.setVisible(true);
        }
    }

    private class cancelButton implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new sortframe().Sort();
            sortdelete.dispose();
        }
    }
}
