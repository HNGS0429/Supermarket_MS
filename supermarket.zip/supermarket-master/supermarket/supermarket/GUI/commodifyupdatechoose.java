package supermarket.GUI;

import supermarket.commodify.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

public class commodifyupdatechoose {
    JFrame choose = new JFrame("更改商品信息");
    JTextField user = new JTextField();
    JLabel title_I = new JLabel("请输入要更改的商品编号");
    JButton sure = new JButton("确认");
    JButton cancel = new JButton("取消");

    public void Choose() {
        user.setBounds(111, 100, 240, 30);
        sure.setBounds(111, 160, 75, 30);
        sure.addActionListener(new sureButton(user));
        cancel.setBounds(274, 160, 75, 30);
        cancel.addActionListener(new cancelButton());
        title_I.setBounds(130, 70, 180, 30);
        title_I.setFont(new Font("微软雅黑", Font.BOLD, 15));
        choose.setBounds(744, 374, 429, 359);
        choose.setResizable(false);
        choose.setLayout(null);
        choose.setVisible(true);
        choose.add(title_I);
        choose.add(user);
        choose.add(sure);
        choose.add(cancel);

        choose.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new commodifyframe().Commodify();
                choose.dispose();
            }
        });

    }

    private class sureButton implements ActionListener {
        private JTextField number = new JTextField();


        public sureButton(JTextField number) {
            this.number = number;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String Id = number.getText();
            int id_s = Integer.parseInt(Id);
            commodify commodify = new commodify();
            commodifyDAOImpl cd = new commodifyDAOImpl();
            Vector<commodify> vector = cd.selectById(id_s);
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel("请输入正确");
            JLabel tip2 = new JLabel("的商品编号");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            if (vector.isEmpty()) {
                comp.setVisible(true);
            } else {
                JFrame update = new JFrame("更改商品信息");
                JButton submit = new JButton("确认更改");
                JLabel id = new JLabel("请输入要更新的信息");
                JLabel name = new JLabel("商品名称");
                JLabel type = new JLabel("商品分类");
                JLabel detail = new JLabel("商品详情");
                JLabel price = new JLabel("商品价格");
                JLabel num = new JLabel("商品库存");
                JLabel statue = new JLabel("上架状态");
                JTextField name_tx = new JTextField();
                JTextField type_tx = new JTextField();
                JTextField detail_tx = new JTextField();
                JTextField price_tx = new JTextField();
                JTextField num_tx = new JTextField();
                JComboBox statue_tx = new JComboBox();
                update.setResizable(false);
                update.setLayout(null);
                id.setFont(new Font("微软雅黑",Font.PLAIN,20));
                id.setBounds(131,10,270,30);
                name.setFont(new Font("微软雅黑",Font.PLAIN,15));
                name.setBounds(41,45,60,30);
                name_tx.setBounds(111,45,240,30);
                type.setFont(new Font("微软雅黑",Font.PLAIN,15));
                type.setBounds(41,80,60,30);
                type_tx.setBounds(111,80,240,30);
                detail.setFont(new Font("微软雅黑",Font.PLAIN,15));
                detail.setBounds(41,115,60,30);
                detail_tx.setBounds(111,115,240,30);
                price.setFont(new Font("微软雅黑",Font.PLAIN,15));
                price.setBounds(41,150,60,30);
                price_tx.setBounds(111,150,240,30);
                num.setFont(new Font("微软雅黑",Font.PLAIN,15));
                num.setBounds(41,185,90,30);
                num_tx.setBounds(111,185,240,30);
                statue.setFont(new Font("微软雅黑",Font.PLAIN,15));
                statue.setBounds(41,220,60,30);
                statue_tx.setBounds(111,220,240,30);
                statue_tx.addItem("在售");
                statue_tx.addItem("下架");
                submit.setBounds(250,270,100,30);
                submit.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        String name = name_tx.getText();
                        String type = type_tx.getText();
                        String detail = detail_tx.getText();
                        String price = price_tx.getText();
                        String num = num_tx.getText();
                        String statue = (String) statue_tx.getSelectedItem();
                        if(name.equals("") || price.equals("") || num.equals(" "))
                        {
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("更改失败");
                            sure.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    comp.dispose();
                                }
                            });

                        }
                        else
                        {
                            int num_s = Integer.parseInt(num);
                            double price_d = Double.parseDouble(price);
                            commodify commodify = new commodify();
                            commodify.setId(id_s);
                            commodify.setName(name);
                            commodify.setType(type);
                            commodify.setDetail(detail);
                            commodify.setPrice(price_d);
                            commodify.setNum(num_s);
                            commodify.setStatue(statue);
                            commodifyDAOImpl cd = new commodifyDAOImpl();
                            cd.UpdateCommodify(commodify);
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("更改完成");
                            sure.addActionListener(new ActionListener() {
                                @Override
                                public void actionPerformed(ActionEvent e) {
                                    comp.dispose();
                                    update.dispose();
                                    new commodifyupdatechoose().Choose();
                                }
                            });
                        }
                        comp.add(tip);
                        comp.add(sure);
                        comp.setVisible(true);
                    }
                });

                update.add(id);
                update.add(name);
                update.add(name_tx);
                update.add(type);
                update.add(type_tx);
                update.add(detail);
                update.add(detail_tx);
                update.add(price);
                update.add(price_tx);
                update.add(num);
                update.add(num_tx);
                update.add(statue);
                update.add(statue_tx);
                update.add(submit);
                update.setVisible(true);
                update.setBounds(744,374,429,359);
                update.addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {
                        update.dispose();
                        new commodifyupdatechoose().Choose();
                    }
                });
                choose.dispose();
            }


        }
    }

    private class cancelButton implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            new commodifyframe().Commodify();
            choose.dispose();
        }
    }
}
