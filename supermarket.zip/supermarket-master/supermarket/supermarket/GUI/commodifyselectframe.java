package supermarket.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

class commodifyselectframe {
    JFrame select = new JFrame("商品查询");
    JLabel tips = new JLabel("请选择查询方式");
    JButton id = new JButton("商品编号");
    JButton name = new JButton("商品名称");
    
    public void Select()
    {
        select.setResizable(false);
        select.setLayout(null);
        id.setBounds(71,100,270,50);
        id.setFont(new Font("微软雅黑",Font.PLAIN,20));
        name.setBounds(71,180,270,50);
        name.setFont(new Font("微软雅黑",Font.PLAIN,20));
        tips.setFont(new Font("微软雅黑",Font.PLAIN,30));
        tips.setBounds(71,40,270,40);
        id.addActionListener(new idListener());
        name.addActionListener(new nameListener());


        select.add(id);
        select.add(name);
        select.add(tips);
        select.setVisible(true);
        select.setBounds(744,374,429,359);
        select.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new commodifyframe().Commodify();
            }
        });
    }
    private class idListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyselectid().Commodifyselectid();
            select.dispose();

        }
    }
    private class nameListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyselectname().Commodifyselectname();
            select.dispose();
        }
    }
}
