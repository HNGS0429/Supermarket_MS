package supermarket.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class accounterframe {
    JFrame accounterframe = new JFrame("收银员");
    JButton account = new JButton("商品结算");
    JButton order = new JButton("订单查询");
    public void accounter()
    {
        accounterframe.setBounds(744,374,429,359);
        accounterframe.setResizable(false);
        accounterframe.setLayout(null);
        accounterframe.setVisible(true);
        account.setFont(new Font("微软雅黑",Font.PLAIN,15));
        account.setBounds(71,70,270,50);
        account.addActionListener(new accountLitener());
        order.setFont(new Font("微软雅黑",Font.PLAIN,15));
        order.setBounds(71,150,270,50);
        order.addActionListener(new orderLitener());

        accounterframe.add(account);
        accounterframe.add(order);
        accounterframe.addWindowListener(new WindowAdapter() {
        @Override
        public void windowClosing(WindowEvent e) {
            accounterframe.dispose();
            new mainframe().Main();
        }
    });
    }

    private class accountLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new accountframe().Account();
        }
    }
    private class orderLitener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new orderframe().Order();
        }
    }

}





