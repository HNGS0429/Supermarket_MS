package supermarket.GUI;

import supermarket.commodify.commodify;
import supermarket.commodify.commodifyDAOImpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

public class commodifyselectname {
    DefaultListModel model = new DefaultListModel();
    JScrollPane js = new JScrollPane();
    JList result = new JList();
    JFrame commodifyselect = new JFrame("查询商品信息");
    JButton submit = new JButton("查询商品");
    JLabel id = new JLabel("请输入商品名称");
    JTextField id_tx = new JTextField();

    public void Commodifyselectname() {
        result.setModel(model);
        commodifyselect.setResizable(false);
        commodifyselect.setLayout(null);
        id.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        id.setBounds(41, 30, 120, 30);
        id_tx.setBounds(41, 60, 240, 30);
        submit.setBounds(290, 60, 90, 30);
        submit.addActionListener(new submitListener(id_tx));
        js.setBounds(40,100,340,200);
        js.setViewportView(result);

        commodifyselect.add(id);
        commodifyselect.add(id_tx);
        commodifyselect.add(js);
        commodifyselect.add(submit);
        commodifyselect.setVisible(true);
        commodifyselect.setBounds(744, 374, 429, 359);
        commodifyselect.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new commodifyselectframe().Select();
            }
        });
    }

    private class submitListener implements ActionListener
    {
        private JTextField textField = new JTextField();//定义私有JTextField对象

        public submitListener(JTextField textField) {
            this.textField = textField;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel("请输入正确");
            JLabel tip2 = new JLabel("的商品名称");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String ID = textField.getText();
            if(ID.equals(""))
            {
                comp.setVisible(true);
            }
            else
            {
                commodify commodify = new commodify();
                commodifyDAOImpl cd = new commodifyDAOImpl();
                Vector<commodify> vector = cd.selectByName(ID);
                if (vector.isEmpty()) {
                    comp.setVisible(true);
                } else {
                    model.removeAllElements();
                    model.addElement(vector);
                }

            }
        }
    }


}
