package supermarket.GUI;

import supermarket.sort.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class sortupdateframe {
    JFrame sortupdate = new JFrame("修改分类信息");
    JLabel sort = new JLabel("分类名称");
    JLabel state = new JLabel("分类下有无商品");
    JTextField sort_tx = new JTextField();
    JComboBox state_tx = new JComboBox();
    JButton sure = new JButton("修改");
    JButton cancel = new JButton("取消");
    public void Update() {
        sort.setFont(new Font("微软雅黑",Font.PLAIN,15));
        sort.setBounds(65,50,60,30);
        sort_tx.setBounds(141,50,210,30);
        state.setFont(new Font("微软雅黑",Font.PLAIN,15));
        state.setBounds(21,100,110,30);
        state_tx.setBounds(141,100,210,30);
        state_tx.addItem("有商品");
        state_tx.addItem("无商品");
        sure.setBounds(111, 150, 75, 30);
        sure.addActionListener(new sureButton(sort_tx,state_tx));
        cancel.setBounds(274, 150, 75, 30);
        cancel.addActionListener(new cancelButton());

        sortupdate.setBounds(744, 374, 429, 359);
        sortupdate.setResizable(false);
        sortupdate.setLayout(null);
        sortupdate.setVisible(true);
        sortupdate.add(sort);
        sortupdate.add(state);
        sortupdate.add(sort_tx);
        sortupdate.add(state_tx);
        sortupdate.add(sure);
        sortupdate.add(cancel);
        sortupdate.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new sortframe().Sort();
            }
        });
    }

    private class sureButton implements ActionListener
    {
        JTextField sort_tx = new JTextField();
        JComboBox state_tx = new JComboBox();

        public sureButton(JTextField sort_tx, JComboBox state_tx) {
            this.sort_tx = sort_tx;
            this.state_tx = state_tx;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            JLabel tip2 = new JLabel();
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String sort = sort_tx.getText();
            String state = (String) state_tx.getSelectedItem();
            if(sort.equals(""))
            {
                tip.setText("请输入正确");
                tip2.setText("的分类信息");
            }
            else
            {
                SortManage sortManage = new SortManage();
                SortManageDAOimpl sd = new SortManageDAOimpl();
                sortManage.setSort(sort);
                sortManage.setState(state);
                if(sd.updateSort(sortManage))
                {
                    tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                    tip.setBounds(50,20,100,40);
                    tip2.setVisible(false);
                    tip.setText("修改完成");
                }
                else
                {
                    tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                    tip.setBounds(50,20,100,40);
                    tip2.setVisible(false);
                    tip.setText("修改失败");
                }
            }
            comp.setVisible(true);
        }
    }

    private class cancelButton implements ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent e) {
            new sortframe().Sort();
            sortupdate.dispose();
        }
    }


}
