package supermarket.GUI;

public class GUIDemo {
    public static void main(String[] args) {
        new mainframe().Main();

//        new adminframe().admin();
//        new storframe().store();
    }
}
