package supermarket.GUI;

import supermarket.user.User;
import supermarket.user.UserDAOimpl;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class registerframe {
    JFrame registerframe = new JFrame("账户注册");
    JTextField usernum = new JTextField();
    JTextField userpwd = new JTextField();
    JTextField username = new JTextField();
    JTextField usertel = new JTextField();
    JComboBox userrole = new JComboBox();
    JLabel num = new JLabel("用户名");
    JLabel pwd = new JLabel("密   码");
    JLabel name = new JLabel("姓   名");
    JLabel tel = new JLabel("手机号");
    JLabel role = new JLabel("身   份");
    JButton submit = new JButton("完成注册");
    
    public void Register()
    {
        userrole.setFont(new Font("微软雅黑",Font.PLAIN,15));
        userrole.addItem("管理员");
        userrole.addItem("库管员");
        userrole.addItem("收银员");

        registerframe.setResizable(false);
        registerframe.setLayout(null);
        num.setFont(new Font("微软雅黑",Font.PLAIN,15));
        num.setBounds(51,30,60,30);
        usernum.setBounds(111,30,240,30);
        pwd.setFont(new Font("微软雅黑",Font.PLAIN,15));
        pwd.setBounds(51,70,60,30);
        userpwd.setBounds(111,70,240,30);
        name.setFont(new Font("微软雅黑",Font.PLAIN,15));
        name.setBounds(51,110,60,30);
        username.setBounds(111,110,240,30);
        tel.setFont(new Font("微软雅黑",Font.PLAIN,15));
        tel.setBounds(51,150,60,30);
        usertel.setBounds(111,150,240,30);
        usertel.setDocument(new PlainDocument()
        {
            @Override
            public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
                String text = usertel.getText();
                if (text.length() + str.length() > 11) {
                    Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.insertString(offs, str, a);
            }
        });
        role.setFont(new Font("微软雅黑",Font.PLAIN,15));
        role.setBounds(51,190,60,30);
        userrole.setBounds(111,190,240,30);
        submit.setBounds(250,250,100,30);
        submit.addActionListener(new submitListener(usernum,userpwd,username,usertel,userrole));

        registerframe.add(num);
        registerframe.add(usernum);
        registerframe.add(pwd);
        registerframe.add(userpwd);
        registerframe.add(name);
        registerframe.add(username);
        registerframe.add(tel);
        registerframe.add(usertel);
        registerframe.add(role);
        registerframe.add(userrole);
        registerframe.add(submit);


        registerframe.setBounds(744,374,429,359);
        registerframe.setVisible(true);
        registerframe.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                registerframe.dispose();
                new mainframe().Main();
            }
        });

    }
    private class submitListener implements ActionListener
    {
        private JTextField usernum = new JTextField();
        private JTextField userpwd = new JTextField();
        private JTextField username = new JTextField();
        private JTextField usertel = new JTextField();
        private JComboBox userrole = new JComboBox();

        public submitListener(JTextField usernum, JTextField userpwd, JTextField username, JTextField usertel, JComboBox userrole) {
            this.usernum = usernum;
            this.userpwd = userpwd;
            this.username = username;
            this.usertel = usertel;
            this.userrole = userrole;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            String id = usernum.getText();
            String pwd = userpwd.getText();
            String name = username.getText();
            String tel = usertel.getText();
            String role = (String) userrole.getSelectedItem();
            User user = new User();
            UserDAOimpl ud = new UserDAOimpl();
            user.setId(id);
            user.setName(name);
            user.setPwd(pwd);
            user.setTel(tel);
            user.setRole(role);
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel("注册成功");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                    registerframe.dispose();
                    new mainframe().Main();
                }
            });
            sure.setBounds(60,80,80,40);
            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
            tip.setBounds(50,20,100,40);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            if(ud.addUser(user))
            {
                comp.add(tip);
            }
            else
            {
                tip.setText("注册失败");
                comp.add(tip);
            }
            comp.add(sure);
            comp.setVisible(true);

        }
    }

}
