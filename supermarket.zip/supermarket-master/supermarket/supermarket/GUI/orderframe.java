package supermarket.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class orderframe {
    JFrame order = new JFrame("订单查询");
    JLabel tips = new JLabel("请选择查询方式");
    JButton id = new JButton("订单单号");
    JButton time = new JButton("创建时间");
    
    public void Order()
    {
        order.setResizable(false);
        order.setLayout(null);
        id.setBounds(71,100,270,50);
        id.setFont(new Font("微软雅黑",Font.PLAIN,20));
        time.setBounds(71,180,270,50);
        time.setFont(new Font("微软雅黑",Font.PLAIN,20));
        tips.setFont(new Font("微软雅黑",Font.PLAIN,30));
        tips.setBounds(71,40,270,40);
        id.addActionListener(new idListener());
        time.addActionListener(new timeListener());

     
        order.add(id);
        order.add(time);
        order.add(tips);
        order.setVisible(true);
        order.setBounds(744,374,429,359);
        order.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }
    private class idListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            order.dispose();
            new orderselectididframe().Orderselectid();

        }
    }
    private class timeListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            order.dispose();
            new orderselecttimetimeframe().Orderselectdate();
        }
    }
}
