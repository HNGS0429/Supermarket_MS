package supermarket.GUI;

import supermarket.order.order;
import supermarket.order.orderDAOImpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

class orderselecttimetimeframe {
    DefaultListModel model = new DefaultListModel();
    JScrollPane js = new JScrollPane();
    JList result = new JList();
    JFrame  orderselectdate = new JFrame("查询订单");
    JButton submit = new JButton("查询订单");
    JLabel id = new JLabel("请输入订单编号");
    JComboBox year = new JComboBox();
    JComboBox month = new JComboBox();
    JComboBox day = new JComboBox();

    public void Orderselectdate() {
        result.setModel(model);
        orderselectdate.setResizable(false);
        orderselectdate.setLayout(null);
        id.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        id.setBounds(41, 30, 120, 30);
        year.setBounds(45, 60, 100, 30);
        for(int i=1990;i<2050;i++)
        {
            year.addItem(i+"年");
        }
        month.setBounds(145, 60, 70, 30);
        for(int i=1;i<13;i++)
        {
            month.addItem(i+"月");
        }
        year.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String y = (String) year.getSelectedItem();
                y = y.substring(0,4);
                int year = Integer.parseInt(y);
                if((year % 4==0 && year%100!=0) || year%400==0)
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "2月":
                                    for(int i=1;i<30;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "1月","3月","5月","7月","8月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "4月","6月","9月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                            }
                        }
                    });
                }
                else
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "2月":
                                    for(int i=1;i<29;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "1月","3月","5月","7月","8月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                                case "4月","6月","9月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        day.addItem(i+"日");
                                    }
                                    break;
                            }
                        }
                    });
                }
            }
        });
        day.setBounds(215, 60, 70, 30);
        submit.setBounds(290, 60, 90, 30);
        submit.addActionListener(new submitListener(year,month,day));
        js.setBounds(40,100,340,200);
        js.setViewportView(result);

        orderselectdate.add(id);
        orderselectdate.add(year);
        orderselectdate.add(month);
        orderselectdate.add(day);
        orderselectdate.add(js);
        orderselectdate.add(submit);
        orderselectdate.setVisible(true);
        orderselectdate.setBounds(744, 374, 429, 359);
        orderselectdate.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new orderframe().Order();
            }
        });
    }

    private class submitListener implements ActionListener
    {
        private JComboBox year = new JComboBox();
        private JComboBox month = new JComboBox();
        private JComboBox day = new JComboBox();

        public submitListener(JComboBox year, JComboBox month, JComboBox day) {
            this.year = year;
            this.month = month;
            this.day = day;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            result.removeAll();
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel("请选择正确");
            JLabel tip2 = new JLabel("的创建日期");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String ID = (String) year.getSelectedItem() + month.getSelectedItem() + day.getSelectedItem();
            order order = new order();
            orderDAOImpl od = new orderDAOImpl();
            Vector<order> vector = od.selectByDate(ID);
            if (vector.isEmpty()) {
                comp.setVisible(true);
            } else {
                model.removeAllElements();
                model.addElement(vector);
            }


        }
    }
}
