package supermarket.GUI;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class commodifyframe {
    JFrame commodify = new JFrame("商品管理");
    JButton addcommodify = new JButton("添加商品信息");
    JButton deletecommodify = new JButton("删除商品信息");
    JButton updatecommodify = new JButton("修改商品信息");
    JButton selectcommodify = new JButton("查询商品信息");
    public void Commodify()
    {
        commodify.setResizable(false);
        commodify.setLayout(null);
        addcommodify.setBounds(71,40,270,40);
        addcommodify.addActionListener(new addListener());
        deletecommodify.setBounds(71,100,270,40);
        deletecommodify.addActionListener(new deleteListener());
        updatecommodify.setBounds(71,160,270,40);
        updatecommodify.addActionListener(new updateListener());
        selectcommodify.setBounds(71,220,270,40);
        selectcommodify.addActionListener(new selectListener());
        commodify.add(addcommodify);
        commodify.add(deletecommodify);
        commodify.add(updatecommodify);
        commodify.add(selectcommodify);
        commodify.setVisible(true);
        commodify.setBounds(744,374,429,359);
        commodify.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }

    private class addListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyaddframe().Add();
            commodify.dispose();

        }
    }

    private class updateListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyupdatechoose().Choose();
            commodify.dispose();

        }
    }

    private class selectListener implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifyselectframe().Select();
            commodify.dispose();

        }
    }

    private class deleteListener implements  ActionListener
    {

        @Override
        public void actionPerformed(ActionEvent e) {
            new commodifydeleteframe().Delete();
            commodify.dispose();
        }
    }


}
