package supermarket.GUI;

import supermarket.commodify.*;
import supermarket.order.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class commodifydeleteframe {
    JFrame delete = new JFrame("删除商品信息");
    JTextField id = new JTextField();
    JLabel title_I = new JLabel("请输入要删除的商品编号");
    JButton sure = new JButton("确认");
    JButton cancel = new JButton("取消");
    public void Delete() {
        id.setBounds(111, 100, 240, 30);
        sure.setBounds(111, 160, 75, 30);
        sure.addActionListener(new sureButton(id));
        cancel.setBounds(274, 160, 75, 30);
        cancel.addActionListener(new cancelButton());
        title_I.setBounds(130, 70, 180, 30);
        title_I.setFont(new Font("微软雅黑", Font.BOLD, 15));
        delete.setBounds(744, 374, 429, 359);
        delete.setResizable(false);
        delete.setLayout(null);
        delete.setVisible(true);
        delete.add(title_I);
        delete.add(id);
        delete.add(sure);
        delete.add(cancel);

        delete.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new commodifyframe().Commodify();
                delete.dispose();
            }
        });

    }

    private class sureButton implements ActionListener
    {
        private JTextField id = new JTextField();

        public sureButton(JTextField id) {
            this.id = id;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            JLabel tip2 = new JLabel("的商品编号");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String ID = id.getText();
            if(ID.equals(""))
            {
                tip.setText("请输入正确");
                tip2.setText("的商品编号");
            }
            else
            {
                int id = Integer.parseInt(ID);
                commodifyDAOImpl cd = new commodifyDAOImpl();
                if(cd.selectById(id).isEmpty())
                {
                    tip.setText("请输入正确");
                    tip2.setText("的商品编号");
                }
                else
                {
                    orderDAOImpl od = new orderDAOImpl();
                    if(od.selectCommdifyById(id).isEmpty())
                    {
                        if(cd.DeleteCommodify(id))
                        {
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,15));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("商品已删除");
                        }
                        else
                        {
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("删除失败");
                        }
                    }
                    else
                    {
                        if (cd.FakedeleteCommodify(id))
                        {
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,15));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("商品已删除");
                        }
                        else
                        {
                            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                            tip.setBounds(50,20,100,40);
                            tip2.setVisible(false);
                            tip.setText("删除失败");
                        }
                    }
                }
            }
            comp.setVisible(true);

        }
    }

    private class cancelButton implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e)
        {
            new commodifyframe().Commodify();
            delete.dispose();
        }
    }
}
