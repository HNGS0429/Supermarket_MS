package supermarket.GUI;

import supermarket.commodify.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class commodifyaddframe {
    JFrame add = new JFrame("添加商品信息");
    JButton submit = new JButton("添加商品");
    JLabel id = new JLabel("商品编号");
    JLabel name = new JLabel("商品名称");
    JLabel type = new JLabel("商品分类");
    JLabel detail = new JLabel("商品详情");
    JLabel price = new JLabel("商品价格");
    JLabel num = new JLabel("商品库存");
    JLabel statue = new JLabel("上架状态");
    JTextField id_tx = new JTextField();
    JTextField name_tx = new JTextField();
    JTextField type_tx = new JTextField();
    JTextField detail_tx = new JTextField();
    JTextField price_tx = new JTextField();
    JTextField num_tx = new JTextField();
    JComboBox statue_tx = new JComboBox();
    public void Add()
    {
        add.setResizable(false);
        add.setLayout(null);
        id.setFont(new Font("微软雅黑",Font.PLAIN,15));
        id.setBounds(41,10,60,30);
        id_tx.setBounds(111,10,240,30);
        name.setFont(new Font("微软雅黑",Font.PLAIN,15));
        name.setBounds(41,45,60,30);
        name_tx.setBounds(111,45,240,30);
        type.setFont(new Font("微软雅黑",Font.PLAIN,15));
        type.setBounds(41,80,60,30);
        type_tx.setBounds(111,80,240,30);
        detail.setFont(new Font("微软雅黑",Font.PLAIN,15));
        detail.setBounds(41,115,60,30);
        detail_tx.setBounds(111,115,240,30);
        price.setFont(new Font("微软雅黑",Font.PLAIN,15));
        price.setBounds(41,150,60,30);
        price_tx.setBounds(111,150,240,30);
        num.setFont(new Font("微软雅黑",Font.PLAIN,15));
        num.setBounds(41,185,90,30);
        num_tx.setBounds(111,185,240,30);
        statue.setFont(new Font("微软雅黑",Font.PLAIN,15));
        statue.setBounds(41,220,60,30);
        statue_tx.setBounds(111,220,240,30);
        statue_tx.addItem("在售");
        statue_tx.addItem("下架");
        submit.setBounds(250,270,100,30);
        submit.addActionListener(new submitListener(id_tx,name_tx,type_tx,detail_tx,price_tx,num_tx,statue_tx));

        add.add(id);
        add.add(id_tx);
        add.add(name);
        add.add(name_tx);
        add.add(type);
        add.add(type_tx);
        add.add(detail);
        add.add(detail_tx);
        add.add(price);
        add.add(price_tx);
        add.add(num);
        add.add(num_tx);
        add.add(statue);
        add.add(statue_tx);
        add.add(submit);
        add.setVisible(true);
        add.setBounds(744,374,429,359);
        add.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                add.dispose();
                new commodifyframe().Commodify();
            }
        });
    }
    
    private class submitListener implements ActionListener
    {
        private JTextField cid = new JTextField();
        private JTextField cname = new JTextField();
        private JTextField ctype = new JTextField();
        private JTextField cdetail = new JTextField();
        private JTextField cprice = new JTextField();
        private JTextField cnum = new JTextField();
        private JComboBox cstatue = new JComboBox();

        public submitListener(JTextField cid, JTextField cname, JTextField ctype, JTextField cdetail, JTextField cprice, JTextField cnum, JComboBox cstatue) {
            this.cid = cid;
            this.cname = cname;
            this.ctype = ctype;
            this.cdetail = cdetail;
            this.cprice = cprice;
            this.cnum = cnum;
            this.cstatue = cstatue;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                    add.dispose();
                    new commodifyaddframe().Add();
                }
            });
            sure.setBounds(60,80,80,40);
            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
            tip.setBounds(50,20,100,40);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(sure);
            comp.add(tip);
            String id = cid.getText();
            String name = cname.getText();
            String type = ctype.getText();
            String detail = cdetail.getText();
            String price = cprice.getText();
            String num = cnum.getText();
            String statue = (String) cstatue.getSelectedItem();
            if(id.equals("") || name.equals("") || price.equals("") || num.equals(""))
            {
                tip.setText("添加失败");
            }
            else
            {
                int id_s = Integer.parseInt(id);
                int num_s = Integer.parseInt(num);
                double price_d = Double.parseDouble(price);
                commodify commodify = new commodify();
                commodify.setId(id_s);
                commodify.setName(name);
                commodify.setType(type);
                commodify.setDetail(detail);
                commodify.setPrice(price_d);
                commodify.setNum(num_s);
                commodify.setStatue(statue);

                commodifyDAOImpl cd = new commodifyDAOImpl();

                if(cd.AddCommodify(commodify))
                {
                    tip.setText("添加完成");
                }
                else
                {
                    tip.setText("添加失败");
                }
            }
            comp.setVisible(true);

        }
    }


}
