package supermarket.GUI;

import supermarket.sort.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Vector;

public class sortselectframe {
    DefaultListModel model = new DefaultListModel();
    JScrollPane js = new JScrollPane();
    JList result = new JList();

    JFrame sortselect = new JFrame("查询分类信息");
    JButton sure = new JButton("查询商品");
    JLabel sort = new JLabel("请输入分类名称");
    JTextField sort_tx = new JTextField();
    public void Select() {

        result.setModel(model);

        sort.setFont(new Font("微软雅黑", Font.PLAIN, 16));
        sort.setBounds(41, 30, 120, 30);
        sort_tx.setBounds(41, 60, 240, 30);
        sure.setBounds(290, 60, 90, 30);
        sure.addActionListener(new sureButton(sort_tx));
        js.setBounds(40,100,340,200);
        js.setViewportView(result);


        sortselect.setBounds(744, 374, 429, 359);
        sortselect.setResizable(false);
        sortselect.setLayout(null);
        sortselect.setVisible(true);
        sortselect.add(sort);
        sortselect.add(sort_tx);
        sortselect.add(js);
        sortselect.add(sure);
        sortselect.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new sortframe().Sort();
            }
        });
    }
    private class sureButton implements ActionListener
    {
        JTextField sort_tx = new JTextField();

        public sureButton(JTextField sort_tx) {
            this.sort_tx = sort_tx;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            JLabel tip2 = new JLabel();
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String sort = sort_tx.getText();
            if(sort.equals(""))
            {
                tip.setText("请输入正确");
                tip2.setText("的分类信息");
                comp.setVisible(true);
            }
            else
            {
                SortManageDAOimpl sd = new SortManageDAOimpl();
                Vector vector = sd.findByName(sort);
                if(vector.isEmpty())
                {
                    tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
                    tip.setBounds(50,20,100,40);
                    tip2.setVisible(false);
                    tip.setText("无此分类");
                    comp.setVisible(true);
                }
                else
                {
                    model.removeAllElements();
                    model.addElement(vector);
                }
            }

        }
    }

}
