package supermarket.GUI;

import supermarket.commodify.*;
import supermarket.purchase.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class purchaseaddframe {
    JFrame purchaseadd = new JFrame("进货管理");
    JLabel cid = new JLabel("商品编号");
    JLabel num = new JLabel("进货数量");
    JLabel date = new JLabel("进货日期");

    JTextField cid_tx = new JTextField();
    JTextField num_tx = new JTextField();

    JComboBox year = new JComboBox();
    JComboBox month = new JComboBox();
    JComboBox day = new JComboBox();

    JButton sure = new JButton("确认");
    JButton cancel = new JButton("取消");
    public void Add() {
        cid.setFont(new Font("微软雅黑",Font.PLAIN,15));
        cid.setBounds(41,60,60,30);
        cid_tx.setBounds(111,60,240,30);
        num.setFont(new Font("微软雅黑",Font.PLAIN,15));
        num.setBounds(41,100,60,30);
        num_tx.setBounds(111,100,240,30);
        date.setFont(new Font("微软雅黑",Font.PLAIN,15));
        date.setBounds(41,140,60,30);


        year.setBounds(111,140,100,30);
        for(int i=1990;i<2050;i++)
        {
            year.addItem(i+"年");
        }
        month.setBounds(211,140,70,30);
        for(int i=1;i<13;i++)
        {
            if(i<10)
            {
                month.addItem("0"+i+"月");
            }
            else
            {
                month.addItem(i+"月");
            }

        }
        year.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                day.removeAllItems();
                String y = (String) year.getSelectedItem();
                y = y.substring(0,4);
                int year = Integer.parseInt(y);
                if((year % 4==0 && year%100!=0) || year%400==0)
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "02月":
                                    for(int i=1;i<30;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }

                                    }
                                    break;
                                case "01月","03月","05月","07月","08月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }
                                    }
                                    break;
                                case "04月","06月","09月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }
                                    }
                                    break;
                            }
                        }
                    });
                }
                else
                {
                    month.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            day.removeAllItems();
                            String m = (String) month.getSelectedItem();
                            switch (m)
                            {
                                case "02月":
                                    for(int i=1;i<29;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }
                                    }
                                    break;
                                case "01月","03月","05月","07月","08月","10月","12月":
                                    for(int i=1;i<32;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }
                                    }
                                    break;
                                case "04月","06月","09月","11月":
                                    for(int i=1;i<31;i++)
                                    {
                                        if(i<10)
                                        {
                                            day.addItem("0"+i+"日");
                                        }
                                        else
                                        {
                                            day.addItem(i+"日");
                                        }
                                    }
                                    break;
                            }
                        }
                    });
                }
            }
        });

        day.setBounds(281,140,70,30);

        sure.setBounds(111, 200, 75, 30);
        sure.addActionListener(new sureButton(cid_tx,num_tx,year,month,day));
        cancel.setBounds(274, 200, 75, 30);
        cancel.addActionListener(new cancelButton());

        purchaseadd.setBounds(744, 374, 429, 359);
        purchaseadd.setResizable(false);
        purchaseadd.setLayout(null);
        purchaseadd.setVisible(true);
        purchaseadd.add(cid);
        purchaseadd.add(num);
        purchaseadd.add(date);
        purchaseadd.add(cid_tx);
        purchaseadd.add(num_tx);
        purchaseadd.add(year);
        purchaseadd.add(month);
        purchaseadd.add(day);
        purchaseadd.add(sure);
        purchaseadd.add(cancel);

        purchaseadd.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    }
    private class sureButton implements ActionListener
    {
        private JTextField cid_tx = new JTextField();
        private JTextField num_tx = new JTextField();
        private JComboBox year = new JComboBox();
        private JComboBox month = new JComboBox();
        private JComboBox day = new JComboBox();

        public sureButton(JTextField cid_tx, JTextField num_tx, JComboBox year, JComboBox month, JComboBox day) {
            this.cid_tx = cid_tx;
            this.num_tx = num_tx;
            this.year = year;
            this.month = month;
            this.day = day;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel();
            JLabel tip2 = new JLabel();
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60, 80, 60, 20);
            tip.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip.setBounds(50, 10, 100, 30);
            tip2.setFont(new Font("微软雅黑", Font.PLAIN, 15));
            tip2.setBounds(50, 40, 100, 30);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(tip);
            comp.add(tip2);
            comp.add(sure);
            String cid = cid_tx.getText();
            String num = num_tx.getText();
            String y = (String) year.getSelectedItem();
            String m = (String) month.getSelectedItem();
            String d = (String) day.getSelectedItem();
            String date = y + m + d;
            String id = y.substring(0,4) + m.substring(0,2) + d.substring(0,2);
            if(cid.equals("") || num.equals(""))
            {
                tip.setText("请输入正确");
                tip2.setText("的进货信息");
            }
            else
            {
                int CID = Integer.parseInt(cid);
                int NUM = Integer.parseInt(num);
                commodifyDAOImpl cd = new commodifyDAOImpl();
                if(cd.selectById(CID).isEmpty())
                {
                    tip.setText("请输入正确");
                    tip2.setText("的商品编号");
                }
                else
                {
                    purchaseDAOImpl pd = new purchaseDAOImpl();
                    purchase purchase = new purchase();
                    purchase.setCid(CID);
                    purchase.setNum(NUM);
                    purchase.setDate(date);
                    purchase.setId(id);
                    if(pd.Addpurchase(purchase))
                    {
                        int store = cd.selectNum(CID) + NUM;
                        cd.updateNum(store, CID);
                        tip.setText("进货订单");
                        tip2.setText("添加成功");
                    }
                    else
                    {
                        tip.setText("进货订单");
                        tip2.setText("添加失败");
                    }
                }
            }
            comp.setVisible(true);
        }
    }

    private class cancelButton implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            purchaseadd.dispose();

        }
    }
}
