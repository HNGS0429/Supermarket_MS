package supermarket.GUI;

import supermarket.user.UserDAOimpl;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class mainframe {
    JFrame mainframe = new JFrame("超市管理系统");
    JTextField user = new JTextField();
    JPasswordField pwd = new JPasswordField();
    JLabel title_I = new JLabel("超市管理系统");
    JButton register = new JButton("注册");
    JButton logon = new JButton("登录");
    JLabel user_I = new JLabel("用户名");
    JLabel pwd_I = new JLabel("密   码");
    public void Main()
    {


        pwd.setEchoChar('*');


        user_I.setBounds(51,100,50,30);
        user.setBounds(111,100,240,30);
        pwd.setBounds(111,150,240,30);
        pwd_I.setBounds(51,150,50,30);
        register.setBounds(111,210,75,30);
        register.addActionListener(new registerButton());
        logon.addActionListener(new logonButton(user, pwd));

        logon.setBounds(267,210,75,30);
        title_I.setBounds(150,50,120,30);
        title_I.setFont(new Font("微软雅黑",Font.BOLD,20));
        mainframe.setBounds(744,374,429,359);
        mainframe.setResizable(false);
        mainframe.setLayout(null);
        mainframe.setVisible(true);
        mainframe.add(title_I);
        mainframe.add(user);
        mainframe.add(pwd);
        mainframe.add(pwd_I);
        mainframe.add(user_I);
        mainframe.add(register);
        mainframe.add(logon);

        mainframe.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    }
    private class registerButton implements ActionListener
    {
        @Override
        public void actionPerformed(ActionEvent e) {
            mainframe.dispose();
            new registerframe().Register();
        }
    }

    private class logonButton implements ActionListener
    {
        private JTextField userid = new JTextField();
        private JTextField userpwd = new JTextField();

        public logonButton(JTextField userid, JTextField userpwd) {
            this.userid = userid;
            this.userpwd = userpwd;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            JDialog comp = new JDialog();
            JButton sure = new JButton("确定");
            JLabel tip = new JLabel("用户未注册");
            sure.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    comp.dispose();
                }
            });
            sure.setBounds(60,80,80,40);
            tip.setFont(new Font("微软雅黑",Font.PLAIN,17));
            tip.setBounds(50,20,100,40);
            comp.setLayout(null);
            comp.setResizable(false);
            comp.setBounds(859, 474, 200, 160);
            comp.add(sure);
            comp.add(tip);

            String id = userid.getText();
            String pwd = userpwd.getText();
            UserDAOimpl ud = new UserDAOimpl();
            String pwd_1 = ud.logon(id);
            if(pwd_1==null)
            {
                tip.setText("用户未注册");
                comp.setVisible(true);
            }
            else
            {
                if(pwd.equals(pwd_1))
                {
                    String role = ud.prove(id);
                    switch (role)
                    {
                        case "管理员":
                            new adminframe().admin();
                            break;
                        case "库管员":
                            new storeframe().store();
                            break;
                        case "收银员":
                            new accounterframe().accounter();
                            break;
                    }
                    mainframe.dispose();
                }
                else
                {
                    tip.setText("密码错误");
                    comp.setVisible(true);
                }
            }



        }
    }

}
