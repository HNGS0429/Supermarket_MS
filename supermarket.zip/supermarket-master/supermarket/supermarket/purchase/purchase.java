package supermarket.purchase;

public class purchase {
    private int cid;
    private int num;
    private String date;
    private String id;

    public purchase() {
    }

    public purchase(int cid, int num, String date, String id) {
        super();
        this.cid = cid;
        this.num = num;
        this.date = date;
        this.id = id;
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "purchase{" +
                "cid=" + cid +
                ", num=" + num +
                ", date='" + date + '\'' +
                ", id='" + id + '\'' +
                '}';
    }
}
