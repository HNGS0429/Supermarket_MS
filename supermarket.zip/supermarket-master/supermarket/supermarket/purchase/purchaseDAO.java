package supermarket.purchase;

public interface purchaseDAO {
    public boolean Addpurchase(purchase purchase);
}
