package supermarket.purchase;

import supermarket.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class purchaseDAOImpl implements purchaseDAO{
    @Override
    public boolean Addpurchase(purchase purchase) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "insert into purchase values(?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,purchase.getCid());
            pst.setInt(2,purchase.getNum());
            pst.setString(3,purchase.getDate());
            pst.setString(4,purchase.getId());
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }
}
