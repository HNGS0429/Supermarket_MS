package supermarket.commodify;

import supermarket.*;

import java.sql.*;
import java.util.*;

public class commodifyDAOImpl implements commodifyDAO{

    @Override
    public boolean AddCommodify(commodify commodify) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "insert into commodify values(?,?,?,?,?,?,?,1)";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,commodify.getId());
            pst.setString(2,commodify.getName());
            pst.setString(3,commodify.getType());
            pst.setString(4,commodify.getDetail());
            pst.setDouble(5,commodify.getPrice());
            pst.setInt(6,commodify.getNum());
            pst.setString(7,commodify.getStatue());
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }

    @Override
    public boolean UpdateCommodify(commodify commodify) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "update commodify set name = ?,type = ?, detail = ?,price = ?,num = ?,statue = ? where id = ?  and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(7,commodify.getId());
            pst.setString(1,commodify.getName());
            pst.setString(2,commodify.getStatue());
            pst.setString(3,commodify.getDetail());
            pst.setDouble(4,commodify.getPrice());
            pst.setInt(5,commodify.getNum());
            pst.setString(6,commodify.getStatue());
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }


    @Override
    public boolean DeleteCommodify(int id) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "delete from commodify where id = ?  and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,id);
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }

    @Override
    public Vector<commodify> selectById(int id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        commodify commodify = null;
        Vector<commodify> vector = new Vector<commodify>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from commodify where id = ? and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,id);
            rs = pst.executeQuery();
            while(rs.next())
            {
                commodify = new commodify();
                commodify.setId(rs.getInt(1));
                commodify.setName(rs.getString(2));
                commodify.setType(rs.getString(3));
                commodify.setDetail(rs.getString(4));
                commodify.setPrice(rs.getDouble(5));
                commodify.setNum(rs.getInt(6));
                commodify.setStatue(rs.getString(7));
                vector.add(commodify);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }

    @Override
    public Vector<commodify> selectByName(String name) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        commodify commodify = null;
        Vector<commodify> vector = new Vector<commodify>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from commodify where name = ?  and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setString(1,name);
            rs = pst.executeQuery();
            while(rs.next())
            {
                commodify = new commodify();
                commodify.setId(rs.getInt(1));
                commodify.setName(rs.getString(2));
                commodify.setType(rs.getString(3));
                commodify.setDetail(rs.getString(4));
                commodify.setPrice(rs.getDouble(5));
                commodify.setNum(rs.getInt(6));
                commodify.setStatue(rs.getString(7));
                vector.add(commodify);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }

    @Override
    public Vector<commodify> selectAll() {
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        commodify commodify = null;
        Vector<commodify> vector = new Vector<commodify>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from commodify  and visible = 1";
            st = conn.createStatement();
            rs = st.executeQuery(sql);
            while(rs.next())
            {
                commodify = new commodify();
                commodify.setId(rs.getInt(1));
                commodify.setName(rs.getString(2));
                commodify.setType(rs.getString(3));
                commodify.setDetail(rs.getString(4));
                commodify.setPrice(rs.getDouble(5));
                commodify.setNum(rs.getInt(6));
                commodify.setStatue(rs.getString(7));
                vector.add(commodify);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,st,conn);
        }
        return vector;
    }

    @Override
    public boolean FakedeleteCommodify(int id) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "update commodify set visible = 0 where id = ?";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,id);
            num = pst.executeUpdate();
            if(num == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }

    @Override
    public int selectNum(int id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        commodify commodify = null;
        int store = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select num from commodify where id = ?  and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,id);
            rs = pst.executeQuery();
            while(rs.next())
            {
               store =  rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return store;
    }

    @Override
    public boolean updateNum(int num, int id) {
        Connection conn = null;
        PreparedStatement pst = null;
        int n = 0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "update commodify set num = ? where id = ? and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,num);
            pst.setInt(2,id);
            n = pst.executeUpdate();
            if(n == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst,conn);
        }
    }

    @Override
    public Vector<commodify> selectByNameandID(int id, String name) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        commodify commodify = null;
        Vector<commodify> vector = new Vector<commodify>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from commodify where id = ? and name = ? and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setInt(1,id);
            pst.setString(2,name);
            rs = pst.executeQuery();
            while(rs.next())
            {
                commodify = new commodify();
                commodify.setId(rs.getInt(1));
                commodify.setName(rs.getString(2));
                commodify.setType(rs.getString(3));
                commodify.setDetail(rs.getString(4));
                commodify.setPrice(rs.getDouble(5));
                commodify.setNum(rs.getInt(6));
                commodify.setStatue(rs.getString(7));
                vector.add(commodify);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }

    @Override
    public Vector<commodify> selectBySort(String sort) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        commodify commodify = null;
        Vector<commodify> vector = new Vector<commodify>();
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select * from commodify where type = ? and visible = 1";
            pst = conn.prepareStatement(sql);
            pst.setString(1,sort);
            rs = pst.executeQuery();
            while(rs.next())
            {
                commodify = new commodify();
                commodify.setId(rs.getInt(1));
                commodify.setName(rs.getString(2));
                commodify.setType(rs.getString(3));
                commodify.setDetail(rs.getString(4));
                commodify.setPrice(rs.getDouble(5));
                commodify.setNum(rs.getInt(6));
                commodify.setStatue(rs.getString(7));
                vector.add(commodify);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            CloseResource.close(rs,pst,conn);
        }
        return vector;
    }
}
