package supermarket.commodify;

import java.util.Vector;

public interface commodifyDAO {
    public boolean AddCommodify(commodify commodify);
    public boolean UpdateCommodify(commodify commodify);
    public boolean DeleteCommodify(int id);
    public Vector<commodify> selectById(int id);
    public Vector<commodify> selectByName(String name);
    public Vector<commodify> selectAll();
    public boolean FakedeleteCommodify(int id);
    public int selectNum(int id);
    public boolean updateNum(int num, int id);
    public Vector<commodify> selectByNameandID(int id,String name);
    public Vector<commodify> selectBySort(String sort);
}
