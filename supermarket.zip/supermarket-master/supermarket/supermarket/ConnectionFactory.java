package supermarket;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    static String DriverName = "com.mysql.cj.jdbc.Driver";
    static String Url = "jdbc:mysql://127.0.0.1:3306/mydatabase";
    static String UserName = "root";
    static String Password = "0000";
    public static Connection getConnection()
    {
        try {
            Class.forName(DriverName);
            return DriverManager.getConnection(Url,UserName,Password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return null;
        }

    }
}
