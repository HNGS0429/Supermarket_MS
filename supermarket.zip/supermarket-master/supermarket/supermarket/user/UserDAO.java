package supermarket.user;

import java.util.List;

public interface UserDAO {
    //	//1.获得唯一用户名
//	public String getNewUserNo();
    //2.添加用户
    public boolean addUser(User user);

    //3.用户修改
    public boolean updateUser(User user);

    public boolean updateUserpw(User user);

    //4.用户删除
    public boolean deleteUser(String id);

    //5.用户查询
    public String logon(String id);
    //6.验证身份
    public String prove(String id);
}

