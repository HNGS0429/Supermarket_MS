package supermarket.user;

import supermarket.*;
import java.sql.*;

public class UserDAOimpl implements UserDAO{

    @Override
    public boolean addUser(User user) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num=0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "insert into user values (?,?,?,?,?)";
            pst = conn.prepareStatement(sql);
            pst.setString(1, user.getId());
            pst.setString(2, user.getPwd());
            pst.setString(3, user.getName());
            pst.setString(4, user.getTel());
            pst.setString(5, user.getRole());
            num = pst.executeUpdate();
            if(num==1) {
                return true;
            }else return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst, conn);
        }
    }
    @Override
    public boolean updateUserpw(User user) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num=0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "update user set pwd=? where id=? and name=?";
            pst = conn.prepareStatement(sql);
            pst.setString(2, user.getId());
            pst.setString(1, user.getPwd());
            pst.setString(3, user.getName());
            num = pst.executeUpdate();
            if(num==1) {
                return true;
            }else return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst, conn);
        }
    }
    @Override
    public boolean updateUser(User user) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num=0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "update user set name=?,tel=?,role=? where id=?,pwd=?";
            pst = conn.prepareStatement(sql);
            pst.setString(4, user.getId());
            pst.setString(5, user.getPwd());
            pst.setString(1, user.getName());
            pst.setString(2, user.getTel());
            pst.setString(3, user.getRole());
            num = pst.executeUpdate();
            if(num==1) {
                return true;
            }else return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst, conn);
        }
    }

    @Override
    public boolean deleteUser(String id) {
        Connection conn = null;
        PreparedStatement pst = null;
        int num=0;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "delete from user where id=?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, id);
            num = pst.executeUpdate();
            if(num==1) {
                return true;
            }else return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseResource.close(pst, conn);
        }
    }

    @Override
    public String logon(String id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        User user = null;
        String pwd = null;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select pwd from user where id = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1,id);
            rs = pst.executeQuery();
            while(rs.next())
            {
                pwd = rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
        return pwd;
    }

    @Override
    public String prove(String id) {
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;
        User user = null;
        String role = null;
        try {
            conn = ConnectionFactory.getConnection();
            String sql = "select role from user where id = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1,id);
            rs = pst.executeQuery();
            while(rs.next())
            {
                role = rs.getString(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
        }
        return role;
    }


}

