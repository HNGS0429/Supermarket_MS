SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for commodify
-- ----------------------------
DROP TABLE IF EXISTS `commodify`;
CREATE TABLE `commodify`  (
  `id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `detail` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `price` double NULL DEFAULT NULL,
  `num` int NULL DEFAULT NULL,
  `statue` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `visible` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of commodify
-- ----------------------------

INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (1, '黑人牙膏', '洗漱用品', '刷牙用的', 114.6, 489, '在售', 413);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (2, '牛仔裤', '衣服', '穿的', 172.96, 34, '在售', 144);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (3, '魔芋奶茶', '茶饮', '喝的', 410.02, 467, '在售', 806);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (4, '正阳菜刀', '厨具', '切菜用的', 872.24, 358, '在售', 87);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (5, 'coco薯片', '零食', '吃的', 34.95, 552, '下架', 452);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (6, '万利达热水壶', '厨具', '烧开水的', 910.78, 412, '在售', 892);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (7, '可口可乐', '零食', '喝的', 660.91, 88, '下架', 717);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (8, 'puma外套', '衣服', '穿的', 371.92, 861, '下架', 897);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (9, '景德镇瓷碗', '厨具', '吃饭的家伙', 210.89, 135, '下架', 472);
INSERT INTO `commodify` (`id`, `name`, `type`, `detail`, `price`, `num`, `statue`, `visible`) VALUES (10, '毛竹筷子', '厨具', '吃饭的', 816.19, 547, '下架', 124);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `cid` int NOT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `num` int NOT NULL,
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `dates` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `person` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1001, 'a', 10, '10001', '1991年3月5日', 'GDP');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (4, '正阳菜刀', 699, '1', '2018-03-02', '小布');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (5, 'coco薯片', 500, '10', '2009-07-26', '咸鱼翻身');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (6, '万利达热水壶', 1, '2', '2004-04-09', '咸鱼翻身');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (7, '可口可乐', 238, '3', '2001-05-06', '沈霁豪');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (8, 'puma外套', 280, '4', '2017-11-29', '小布');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (9, '景德镇瓷碗', 21, '5', '2013-03-10', '王艳毫');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (10, '毛竹筷子', 383, '6', '2001-05-22', '咸鱼翻身');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (2, '牛仔裤', 251, '7', '2009-07-26', '咸鱼翻身');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (1, '黑人牙膏', 199, '9', '2018-03-02', '咸鱼翻身');
INSERT INTO `orders` (`cid`, `name`, `num`, `id`, `dates`, `person`) VALUES (3, '魔芋奶茶', 1, '90', '2004-04-09', '沈霁豪');

-- ----------------------------
-- Table structure for purchase
-- ----------------------------
DROP TABLE IF EXISTS `purchase`;
CREATE TABLE `purchase`  (
  `cid` int NULL DEFAULT NULL,
  `num` int NULL DEFAULT NULL,
  `dates` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of purchase
-- ----------------------------
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (923, 777, '2009-02-27', '20090227');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (893, 401, '2004-12-08', '20041208');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (889, 761, '2022-07-25', '20220725');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (756, 440, '2022-12-13', '20221213');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (136, 910, '2005-03-12', '20050312');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (899, 375, '2005-09-01', '20050901');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (471, 411, '2017-08-21', '20170821');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (771, 454, '2014-08-20', '20140820');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (222, 561, '2004-06-15', '20040615');
INSERT INTO `purchase` (`cid`, `num`, `dates`, `id`) VALUES (834, 555, '2014-01-23', '20140123');

-- ----------------------------
-- Table structure for sorttab
-- ----------------------------
DROP TABLE IF EXISTS `sorttab`;
CREATE TABLE `sorttab`  (
  `sort` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `state` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`sort`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sorttab
-- ----------------------------
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('厨具', '有商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('汽车', '有商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('洗漱', '有商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('玩具', '无商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('茶饮', '无商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('衣服', '有商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('调味料', '无商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('零食', '无商品');
INSERT INTO `sorttab` (`sort`, `state`) VALUES ('餐具', '无商品');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `pwd` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `tel` char(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `role` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('宝批龙', '1012', '李宝', '18888888888', '管理员');
INSERT INTO `user` VALUES ('GDP', '123456', '高电平', '13245679832', '管理员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('王艳毫', '4zjHQHeydY', '李宝', '17660449668', '收银员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('蚂蚁上树', 'NWOP63ikPP', '高电平', '17660449669', '管理员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('猪猪', 'lGWD11IGqzX', '王艳毫', '17660449670', '管理员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('咸鱼翻身', '5zjHQHeydY', '王艳毫', '17660449671', '收银员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('布吉岛', '1616513133', '王艳毫', '17660449672', '库管员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('著名“ID”', 'NWOP61ikPP', '沈霁豪', '17660449673', '管理员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('小布', 'lGWD9IGqzX', '沈霁豪', '17660449674', '收银员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('数据库课程设计', '3zjHQHeydY', '沈霁豪', '17660449675', '管理员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('随便起的', 'POx6vB6w4Z', '张三', '17660449676', '收银员');
INSERT INTO `user` (`id`, `pwd`, `name`, `tel`, `role`) VALUES ('沈霁豪', 'E8IF3eS4Z1', '李四', '17660449677', '收银员');

SET FOREIGN_KEY_CHECKS = 1;
